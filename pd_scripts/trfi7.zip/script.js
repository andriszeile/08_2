// Maina apraksta elementa fonu uz gaiši zilu (4 punkti)
//Izveidot funkciju, kas nomaina fonu apraksta
// elementam "info" uz gaiši zilu, ja nospiež
// uz pogas "Mainīt fonu" 


// Parāda lietotāja ievadīto tekstu zem pogas (6 punkti)
//Izveidot funkciju, kas nospiežot uz pogas 
// "Parādīt tekstu" nolasa teksta ievades
// laukā "ievadesLauks" ievadīto tekstu un attēlo
// nākošajā rindkopā "rezultats" 


// Palielina apraksta teksta izmēru (10 punkti)
//Izveidot funkciju, kas nospiežot uz pogas
// "Palielināt apraksta tekstu" palielina elementa
// "skolasApraksts" teksta izmēru uz vērtību 24px
// P.S. Doto stila atribūtu nāksies sameklēt pašiem!!!


